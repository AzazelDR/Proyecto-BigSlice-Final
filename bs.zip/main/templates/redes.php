<div class="accordion-item bg-dark">

    <div class="card bg-danger">
        <h2 class="card-title mx-lg-2 mt-lg-2 text-center fw-bolder" id="tittle"><i class="bi bi-info-square"></i>
            Informacion</h1>

    </div>

    <button class="btn btn-lg w-100 text-white font-monospace" type="button" data-bs-toggle="collapse"
        data-bs-target="#c8" aria-expanded="false" aria-controls="c8">
        <h3 class="header" id="p8">
            Redes Sociales</h2>
    </button>


    <div class=" collapse w-100" id="c8" aria-labelledby="p8" data-bs-parent="#panels">
        <ul class="list-group text-center ">
            <a class="btn text-danger btn-outline-light fst-italic btn-lg" role="button" target="_blank"
                href="https://www.facebook.com/BigSliceSV/"><i class="bi bi-facebook"></i> Facebook</a>
            <a class="btn text-danger btn-outline-light fst-italic btn-lg" role="button" target="_blank"
                href="https://www.instagram.com/bigslice503/"><i class="bi bi-instagram"></i> Instagram</a>
            <a class="btn text-danger btn-outline-light fst-italic btn-lg" role="button" target="_blank"
                href="https://api.whatsapp.com/send?phone=+50377565281"><i class="bi bi-whatsapp"></i> Whatsapp</a>
        </ul>
    </div>
</div>