<div class="accordion-item bg-dark">
    <div class="card bg-danger ">
        <h1 class="card-title mx-lg-2 mt-lg-2 text-center fw-bolder" id="tittle"><i class="bi bi-truck"></i> Delivery
        </h1>

    </div>


    <button class="btn btn-lg w-100 text-white font-monospace" type="button" data-bs-toggle="collapse"
        data-bs-target="#c6" aria-expanded="false" aria-controls="c6">
        <h2 class="header" id="p6"> Telefonos</h2>
    </button>


    <div class=" collapse w-100" id="c6" aria-labelledby="p6" data-bs-parent="#panels">
        <ul class="list-group text-center">
            <a href="tel:+50377565281" class="btn text-danger btn-outline-light fst-italic" role="button"><i
                    class="bi bi-telephone-outbound"></i> 7756-5281</a>
            <a href="tel:22236888" class="btn text-danger btn-outline-light fst-italic" role="button"><i
                    class="bi bi-telephone-outbound"></i> 2223-6888</a>
        </ul>
    </div>
</div>
<div class="accordion-item bg-dark ">


    <button class="btn btn-lg w-100 text-white font-monospace" type="button" data-bs-toggle="collapse"
        data-bs-target="#c7" aria-expanded="false" aria-controls="c7">
        <h2 class="header" id="p7">App </h2>
    </button>

    <div class=" collapse w-100" id="c7" aria-labelledby="p7" data-bs-parent="#panels">
        <ul class="list-group text-center">
            <div class="carousel-item active" data-bs-interval="2000">
                <a title="Get" href="https://getlaapp.com/" target="_blank" class="btn text-danger fst-italic"
                    role="button">

                    <img class="img-fluid" src="assets/img/getapp.jpg" alt="Get" />

                </a>
            </div>

        </ul>
    </div>
</div>