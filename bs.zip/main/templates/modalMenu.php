
<div class="modal fade" id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
               
                <div class="modal-body">
                <img class="img-thumbnail" src="assets/img/alitas.jpg" alt="">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <?php include('main/validateBtnMain/btnpOrdenar.php') ?>
                </div>
            </div>
        </div>
    </div>
<!--Modal2-->
<!--Modal5  -->
<div class="modal fade" id="exampleModal5" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                
                <div class="modal-body">
                <img class="img-thumbnail" src="assets/img/papa.jpg" alt="">
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                <?php include('main/validateBtnMain/btnpOrdenar.php') ?>

                </div>
            </div>
        </div>
    </div>
<!--Modal6-->
<!--Modal9-->
<div class="modal fade" id="exampleModal9" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                
                <div class="modal-body">
                <img class="img-thumbnail" src="assets/img/entradas.jpg" alt="">
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                <?php include('main/validateBtnMain/btnpOrdenar.php') ?>

                </div>
            </div>
        </div>
    </div>
<!--Modal10-->
<!--Modal13-->
<div class="modal fade" id="exampleModal13" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
               
                <div class="modal-body">
                <img class="img-thumbnail" src="assets/img/naturales.jpg" alt="">
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                <?php include('main/validateBtnMain/btnpOrdenar.php') ?>

                </div>
            </div>
        </div>
    </div>
<!--Modal14-->
<div class="modal fade" id="exampleModal14" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                
                <div class="modal-body">
                <img class="img-thumbnail" src="assets/img/sodas.jpg" alt="">
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                <?php include('main/validateBtnMain/btnpOrdenar.php') ?>

                </div>
            </div>
        </div>
    </div>
<!--Modal15-->
<div class="modal fade" id="exampleModal15" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                
                <div class="modal-body">
                <img class="img-thumbnail" src="assets/img/calientes.jpg" alt="">
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                <?php include('main/validateBtnMain/btnpOrdenar.php') ?>

                </div>
            </div>
        </div>
    </div>
<!--Modal16-->
<div class="modal fade" id="exampleModal16" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                
                <div class="modal-body">
                <img class="img-thumbnail" src="assets/img/cervezas.jpg" alt="">
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                <?php include('main/validateBtnMain/btnpOrdenar.php') ?>

                </div>
            </div>
        </div>
    </div>
<!--Modal17-->
<div class="modal fade" id="exampleModal17" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body">
                <img class="img-thumbnail" src="assets/img/vinos.jpg" alt="">
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                <?php include('main/validateBtnMain/btnpOrdenar.php') ?>

                </div>
            </div>
        </div>
    </div>
<!--Modal18-->
<div class="modal fade" id="exampleModal18" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">

                <div class="modal-body">
                <img class="img-thumbnail" src="assets/img/2.jpg" alt="">
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                <?php include('main/validateBtnMain/btnpOrdenar.php') ?>

                </div>
            </div>
        </div>
    </div>
<!--Modal19-->
<div class="modal fade" id="exampleModal19" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">

                <div class="modal-body">
                <img class="img-thumbnail" src="assets/img/3.jpg" alt="">
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                <?php include('main/validateBtnMain/btnpOrdenar.php') ?>

                </div>
            </div>
        </div>
    </div>
<!--Modal20-->
<div class="modal fade" id="exampleModal20" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">

                <div class="modal-body">
                <img class="img-thumbnail" src="assets/img/4.jpg" alt="">
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                <?php include('main/validateBtnMain/btnpOrdenar.php') ?>

                </div>
            </div>
        </div>
    </div>
<!--Modal21-->
<div class="modal fade" id="exampleModal21" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">

                <div class="modal-body">
                <img class="img-thumbnail" src="assets/img/5.jpg" alt="">
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                <?php include('main/validateBtnMain/btnpOrdenar.php') ?>

                </div>
            </div>
        </div>
    </div>
<!--Modal22-->
<div class="modal fade" id="exampleModal22" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">

                <div class="modal-body">
                <img class="img-thumbnail" src="assets/img/6.jpg" alt="">
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                <?php include('main/validateBtnMain/btnpOrdenar.php') ?>

                </div>
            </div>
        </div>
    </div>
<!--Modal23-->
<div class="modal fade" id="exampleModal23" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">

                <div class="modal-body">
                <img class="img-thumbnail" src="assets/img/7.jpg" alt="">
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                <?php include('main/validateBtnMain/btnpOrdenar.php') ?>

                </div>
            </div>
        </div>
    </div>
<!--Modal24-->
<div class="modal fade" id="exampleModal24" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">

                <div class="modal-body">
                <img class="img-thumbnail" src="assets/img/8.jpg" alt="">
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                <?php include('main/validateBtnMain/btnpOrdenar.php') ?>

                </div>
            </div>
        </div>
    </div>
